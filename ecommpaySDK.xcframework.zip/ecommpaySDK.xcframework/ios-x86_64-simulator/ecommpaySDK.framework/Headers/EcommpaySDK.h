//
//  mobilesdk_ios.h
//  mobilesdk-ios
//
//  Created by Ecommpay on 10/31/17.
//  Copyright © 2017 Ecommpay. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for mobilesdk_ios.
FOUNDATION_EXPORT double mobilesdk_iosVersionNumber;

//! Project version string for mobilesdk_ios.
FOUNDATION_EXPORT const unsigned char mobilesdk_iosVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <mobilesdk_ios/PublicHeader.h>

@class EcommpaySDK;;
